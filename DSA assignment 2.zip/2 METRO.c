#include <stdio.h>
#include <stdlib.h>

struct token_details
{ char fr[25],to[25];
int price;
};


typedef struct token_details TD;
void disp_sp(TD[], int);
void read(TD[], int);
void disp_ep(TD[], int);


void main()
{TD x[10];
int n;
printf("enter no of passengers\n");
scanf("%d",&n);
read(x,n);
disp_sp(x,n);
disp_ep(x,n);

}

void read(TD x[10],int n)
{int i;
printf("Enter token details\n\n");
for(i=0;i<n;i++)
{printf("Enter destination from:");
scanf("%s",x[i].fr);
printf("enter destination to:");
scanf("%s",x[i].to);
printf("Enter price:");
scanf("%d",&x[i].price);
}
}
void disp_sp(TD x[10],int n)
{int i;
//printf("\n Token details\n");
for(i=0;i<n;i++)
{printf("from:\t");
printf("%s\n",x[i].fr);
printf("to:\t");
printf("%s\n",x[i].to);
printf("price:\t");
printf("%d\n",x[i].price);
}
}
void disp_ep(TD x[10],int n)
{int i;
//printf("\n reverse Token details\n");
for(i=n-1;i>=0;i--)
{printf("from:\t");
printf("%s\n",x[i].fr);
printf("to:\t");
printf("%s\n",x[i].to);
printf("price:\t");
printf("%d\n",x[i].price);
}
}
