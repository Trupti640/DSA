#include<stdio.h>
int main()
{
    int i,a[100],n;

    printf("enter the elements in array\n");
    scanf("%d",&n);

    printf("enter the elements in an array\n");

     for(i=0;i<n;i++)
     {
         scanf("%d",&a[i]);
     }

     //reverse an array

     printf("display the reverse of elements in array\n");

     for(i=n-1;i>=0;i--)
     {
         printf("%d\n",a[i]);
     }
}
